#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <termios.h>
#include <sys/mman.h>
#include <termios.h> 
#include <sys/select.h>
#include <netdb.h>
#include <time.h>
#include <pthread.h>
#include <linux/input.h>
#include "font.h"


#define TEST_MAGIC 'x'                           //定义幻数
#define TEST_MAX_NR 2                            //定义命令的最大序数

//定义LED的魔幻数
#define LED1 _IO(TEST_MAGIC, 0)
#define LED2 _IO(TEST_MAGIC, 1)
#define LED3 _IO(TEST_MAGIC, 2)
#define LED4 _IO(TEST_MAGIC, 3)

#include <sys/ioctl.h>

#define LCD_PATH "/dev/fb0"
#define TS_PATH "/dev/input/event0"
#define MYDEBUG(format,...) printf("File<"__FILE__">,fnuc(%s),Line[%d]: "format"\n",\
									__FUNCTION__, __LINE__, ##__VA_ARGS__)

int serial2;//串口文件描述符
int lcd_fd;
int ts_fd;
int beep_fd;
int *fbp;


int evr_flag = 0;

//图片显示
int show_bmp(char * bmppathname,int x1,int y1,int z)
{
	int i,x,y,k;
	//定义一个用来存放图片头文件信息的数组
	char bmp_head[54] = {0};
	//定义两个变量，用来保存从头信息中获取到的图片的宽和高
	unsigned short w,h;
	//------------1-----------------
	//打开BMP图片
	int bmp_fd = open(bmppathname,O_RDWR);
	if(bmp_fd == -1)
	{
		printf("open bmp fail\n");
		return -1;
	}	
	//2读取BMP的数据
	//读取头信息，获取图片的宽和高
	read(bmp_fd,bmp_head,54);
	w = bmp_head[19] << 8 | bmp_head[18];
	h = bmp_head[23] << 8 | bmp_head[22];
	//判断要刷的图片是否超过了屏幕范围
	if(w+x1>800 || h+y1>480)
	{
		printf("yuejie\n");
		return -1;
	}
	//根据得到的宽和高来设计合理的数组
	char bmp_buf[w*h*3];
	int lcd_buf[w*h];
	//读取BMP的像素数据
	int ret = read(bmp_fd,bmp_buf,w*h*3);
	if(ret == -1)
	{
		printf("read bmp fail\n");
		return -1;
	}	
	//-------------3--------------
	//对齐像素
	for(i=0;i<w*h;i++)
		lcd_buf[i] = bmp_buf[3*i+0] | bmp_buf[3*i+1]<<8 | bmp_buf[3*i+2]<<16 | 0x00<<24; 
	//在显存中写入数据，相当于显示在LCD屏幕上
	switch(z)
	{
		case 0:
		for(y=0;y<h;y++)
		{
			for(x=0;x<w;x++)
			{		
				*(fbp+800*(y+y1)+x+x1)= lcd_buf[(h-1-y)*w+x];//把图片像素填充到显存中去，让它在LCD屏幕上显示出来
			}
		}
		break;
		case 1:
		//从上到下的显示效果
		for(y=0;y<h;y++)
		{
			for(x=0;x<w;x++)
			{		
				*(fbp+800*(y+y1)+x+x1)= lcd_buf[(h-1-y)*w+x];//把图片像素填充到显存中去，让它在LCD屏幕上显示出来
			}
			usleep(3000);//停顿3毫秒，让我们能够观察到图片是如何在LCD上面显示出来的
		}
		break;
		case 2:
		//从左往右的显示效果
		for(x=0;x<w;x++)
		{
			for(y=0;y<h;y++)
			{		
				*(fbp+800*(y+y1)+x+x1)= lcd_buf[(h-1-y)*w+x];//把图片像素填充到显存中去，让它在LCD屏幕上显示出来

			}
			usleep(2000);//停顿2毫秒，让我们能够观察到图片是如何在LCD上面显示出来的
		}
		break;
		case 3:
		//从下到上：
		for(y=0;y<h;y++)
		{
			for(x=0;x<w;x++)
			{		
				*(fbp + (h-y-1+y1)*800 + x1 + x) = lcd_buf[y*w+x];//把图片像素填充到显存中去，让它在LCD屏幕上显示出来

			}
			usleep(3000);//停顿3毫秒，让我们能够观察到图片是如何在LCD上面显示出来的
		}
		break;
		case 4:
		//从右到左：
		for(x=0; x<w; x++)
		{
			for(y=0; y<h; y++)
			{
				*(fbp + (y+y1)*800 + x1 + w - x - 1) = lcd_buf[(h-1-y)*w+w - x - 1];			
			}							
			usleep(2000);//时间停顿，显示刷的效果				
		}
		break;
		//横百叶窗
		case 5:
		//int k;
		for(x=0;x<(w/8);x++)
		{
			for(y=0;y<h;y++)
			{
				for(k=0;k<8;k++)
				{
					*(fbp+800*(y+y1)+x+x1+k*w/8)= lcd_buf[(h-1-y)*w+x+k*w/8];
				}
			}
			usleep(4000);			
		}
		
		break;
		//竖百叶窗
		case 6:
		//int k;
		for(y=0;y<(h/8);y++)
		{
			for(x=0;x<w;x++)
			{
				for(k=0;k<8;k++)
				{
					*(fbp+800*(y+y1+k*h/8)+x+x1)= lcd_buf[(h-1-y-k*h/8)*w+x];
				}
			}
			usleep(3000);			
		}
	
		break;
		//圆形收缩
		case 7:
		//int k;
		for(k=h*975/1000;k>=0;k-=3)
		{
			for(y=0;y<h;y++)
			{
				for(x=0;x<w;x++)
				{
					if((x-400)*(x-400)+(y-240)*(y-240)>=k*k)
					{
						*(fbp+800*(y+y1)+x+x1)= lcd_buf[(h-1-y)*w+x];
					}
				}
			}
			usleep(500);
		}
	
		break;
		//圆形扩散
		case 8:
		//int k;
		for(k=0;k<(h*975/1000);k+=3)
		{
			for(y=0;y<h;y++)
			{
				for(x=0;x<w;x++)
				{
					if((x-400)*(x-400)+(y-240)*(y-240)<=k*k)
					{
						*(fbp+800*(y+y1)+x+x1)= lcd_buf[(h-1-y)*w+x];
					}
				}
			}
			usleep(500);
		}
	
		break;

	}

	close(bmp_fd);

	return 0 ;
	
}
//获取坐标
int get_x_y(int *x,int *y)
{
	struct input_event buf;
	int ret;
	*x=-1;
	*y=-1;	
	while(1)
	{
		ret = read(ts_fd,&buf,sizeof(buf));//读取输入事件信息
		if(ret < 0)
		{
			perror("read file fail");
			return -1;
		}
		if(buf.type == EV_ABS)//判断是不是触摸屏事件
		{
			if(buf.code == ABS_X)//判断是坐标的X值还是Y值
			{
				*x = buf.value;
				//printf("x=%d\n",x);
			}
			if(buf.code == ABS_Y)
			{
				*y = buf.value;
				//printf("y=%d\n",y);
			}
		}		
		if(*x>-1 && *y>-1)
			break;		
	}
}

//将串口的配置封装成一个函数 
int set_serial(int ser_fd) //参数是你打开的那个串口的文件描述符 
{
	 struct termios old_cfg,new_cfg;
	//1.保存现有串口参数设置
	tcgetattr(ser_fd, &old_cfg);
	//2.原始模式
	cfmakeraw(&new_cfg);
	//3.设置波特率
	cfsetispeed(&new_cfg, B115200); 
	cfsetospeed(&new_cfg, B115200);
	new_cfg.c_cflag |= CLOCAL | CREAD;
	//4.8位数据位，无奇偶校验
	new_cfg.c_cflag &= ~CSIZE;  //无奇偶校验
	new_cfg.c_cflag |= CS8;//CS7  CS6  CS5
	//5.1位停止位
	new_cfg.c_cflag &= ~CSTOPB;
	//6.清除串口缓冲区    while(getchar()!='\n');
	tcflush( ser_fd,TCIOFLUSH);
	new_cfg.c_cc[VTIME] = 0;
	new_cfg.c_cc[VMIN] = 1;
	tcflush ( ser_fd, TCIOFLUSH);
	//7.串口设置使能
	tcsetattr( ser_fd ,TCSANOW,&new_cfg);
}

//串口初始化
int sercial_init(void)
{
	//打开你要使用的串口CON2--/dev/ttySAC1
	serial2=open("/dev/ttySAC1",O_RDWR);
	if(serial2==-1)
	{
		perror("open CON2 failed!\n");
		return -1;
	}
	//配置串口
	set_serial(serial2);
	printf("\n");
}
//初始化所有要使用到得设备
int dev_init()
{
	//初始化中文字库需要的设备
	Init_Font();
	//打开LCD
	lcd_fd = open(LCD_PATH,O_RDWR);
	if(lcd_fd<0)
	{
		perror("open lcd fail");
		return -1;
	}
	//映射内存
	fbp = (int (*))mmap(0,800*480*4,PROT_READ | PROT_WRITE ,MAP_SHARED,lcd_fd,0);
	if(fbp == MAP_FAILED)
	{
		perror("mmap fail");
		return -1;
	}
	//打开触摸屏
	ts_fd = open(TS_PATH,O_RDWR);
	if(ts_fd<0)
	{
		perror("open ts fail");
		return -1;
	}
	
}
//程序退出前关闭所有
int dev_close()
{
	close(lcd_fd);
	close(ts_fd);
	munmap(fbp,800*480*4);
	close(serial2);
	UnInit_Font(); 	
}
//灯光控制
int light_ctl(void)
{
	int x,y;
	//MYDEBUG("start light_ctl\n");
	//显示灯控的界面
	show_bmp("led.bmp",0,0,0);
	int fd;
	fd = open("/dev/Led",O_RDWR); 
	if(fd < 0)
	{
		perror("Can not open /dev/LED\n");
		return 0;
	}
	ioctl(fd, LED1, 1);  //1灯灭
		ioctl(fd, LED2, 1);  //1灯灭
		ioctl(fd, LED3, 1);  //1灯灭
		ioctl(fd, LED4, 1);  //1灯灭
	while(1)
	{
		//读取触摸屏数据
		get_x_y(&x,&y);
		
		//灯1开
		if(x>229 && x<321 && y>182 && y<283)
		{
			ioctl(fd, LED1, 0);  //1灯亮
		}		
		//灯1关
		if(x>326 && x<426 && y>182 && y<283)
		{
			ioctl(fd, LED1, 1);  //1灯灭
		}		
		//灯2开
		if(x>627 && x<725 && y>182 && y<283)
		{
			ioctl(fd, LED2, 0);  //2灯亮
		}
		//灯2关
		if(x>727 && x<829 && y>182 && y<283)
		{
			ioctl(fd, LED2, 1);  //2灯灭
		}		
		//---------------------------------------
		//灯3开
		if(x>229 && x<321 && y>25 && y<125)
		{
			ioctl(fd, LED3, 0);  //3灯亮
		}	
		//灯3关
		   if(x>326 && x<426 &&	y>25 && y<125)
		{
			ioctl(fd, LED3, 1);  //3灯灭
		}		
		//灯4开
		if(x>627 && x<725 && y>25 && y<125)
		{
			ioctl(fd, LED4, 0);  //4灯亮
		}
		//灯4关
		if(x>727 && x<829 && y>25 && y<125)
		{
			ioctl(fd, LED4, 1);  //4灯灭
		}
		
		//--------------------------------------------------------------
			
		//返回的时候可以选择是否关闭所有的灯。。。。
		if(x>469 && x<547 && y>405 && y<481)
		{		
			break;
			
		}
		
	}
	
}

//读取显示温湿度线程
void *evr_ser(void *arg)
{	
	char databuf[1]; //根据驱动来定义数据格式
	beep_fd	=  open("/dev/gz13_beep_drv",O_RDWR);
		if(beep_fd < 0)
	{
		perror("open");
		return beep_fd;
	}
	MYDEBUG("start evr_ser\n");
	unsigned char buffer[7]={0};
	int temp,hum;
	char temp1[3] = {0};
	char hum1[3]= {0};
	char *aa1="1.moderate";
	char *bb1="1.too hot!";
	char *aa2="2.moderate";
	char *bb2="2.too hot!";
			
	while(evr_flag)
	{
		//从串口读取温T 湿H 度的值，保存在7个字节数组里
		//以大写字母A和T来区分是哪个节点闯过来的数据
		read(serial2,buffer,sizeof(buffer));
		//printf("buffer = %s\n",buffer);//将从串口得到的信息打印出来
		if(('T' == buffer[0]))
		{
			//得到温湿度的数值  '0'=48
			temp = (buffer[1]-48)*10+buffer[2]-48;
			temp1[0] = buffer[1];
			temp1[1] = buffer[2];
			hum = (buffer[4]-48)*10+buffer[5]-48;
			hum1[0] = buffer[4];
			hum1[1] = buffer[5];
			printf("temp = %d,hum=%d\n",temp,hum);
			//将得到的温湿度数值显示到LCD上去
			Clean_Area(320,45,60,40,0xff);
			Display_characterX(320,45,temp1,0x00,2);
			Clean_Area(595,45,60,40,0xff);
			Display_characterX(595,45,hum1,0x00,2);
			
			if(temp<27)//温度适中
			{
				databuf[0] = 0; //蜂鸣器不响
		write(beep_fd,databuf,sizeof(databuf));	
			Clean_Area(203,272,170,40,0xff);
			Display_characterX(203,272,aa1,0x00,2);
			}	
			if(temp>=27)//温度过高
			{
				databuf[0] = 1; //蜂鸣器响
				write(beep_fd,databuf,sizeof(databuf));	
			Clean_Area(203,272,170,40,0xff);
			Display_characterX(203,272,bb1,0x00,2);
			}	
			
			
							
			//----拓展，超出范围，音响，闪灯-----------------
#if 0	//不编译
			//注意，这里的温度是举例，如应用到相关实际项目中，需要根据实际情况进行修改
			if(temp<15)//温度过低
			{
				//做出报警处理
			}						
			if(temp>35) //温度过高
			{				
				//蜂鸣器响，6818闪灯
			}				
			if(hum>80) //湿度过高
			{
				//做出报警处理
			}		
#endif
	//-----------------------------------
			sleep(1); //延迟，调节线程时间片
		}
		
		if('A' == buffer[0])
		{
			//得到温湿度的数值
			temp = (buffer[1]-48)*10+buffer[2]-48;
			temp1[0] = buffer[1];
			temp1[1] = buffer[2];
			hum = (buffer[4]-48)*10+buffer[5]-48;
			hum1[0] = buffer[4];
			hum1[1] = buffer[5];
			printf("temp = %d,hum=%d\n",temp,hum);
			//将得到的温湿度数值显示到LCD上去
			Clean_Area(320,195,60,40,0xff);
			Display_characterX(320,195,temp1,0x00,2);
			Clean_Area(595,195,60,40,0xff);
			Display_characterX(595,195,hum1,0x00,2);
			
			if(temp<27)//温度适中
			{
			Clean_Area(509,272,170,40,0xff);
			Display_characterX(509,272,aa2,0x00,2);
			}	
			if(temp>=27)//温度过高
			{
			Clean_Area(509,272,170,40,0xff);
			Display_characterX(509,272,bb2,0x00,2);
			}	
			
			//----拓展，超出范围，音响，闪灯-----------------
#if 0	//不编译
			//注意，这里的温度是举例，如应用到相关实际项目中，需要根据实际情况进行修改
			if(temp<15)//温度过低
			{
				//做出报警处理
			}						
			if(temp>35) //温度过高
			{				
				//蜂鸣器响，6818闪灯
			}				
			if(hum>80) //湿度过高
			{
				//做出报警处理
			}
#endif
	//-----------------------------------
			sleep(1);//延迟，调节线程时间片
		}			
		
	}
	
	
	pthread_exit(NULL);
}

//环境检测
void envr_ctl(void)
{	
	int x,y;
	//定义线程id
	pthread_t evr_id;	
	evr_flag = 1;	

	MYDEBUG("start envr_ctl\n");
	//显示界面
	show_bmp("dht11.bmp",0,0,0);			
	//创建线程
	pthread_create(&evr_id,NULL,evr_ser,NULL);
	
	while(1)
	{
		get_x_y(&x,&y);		
		//返回		
		if(x>483&& x<563 && y>361 && y<432)
		{
			evr_flag = 0;
			printf("environment return \n");
			
			
			break;
		}			
		
	}
	
	//pthread_join(evr_id,NULL);
	pthread_cancel(evr_id);
}

//获取jZIGEBB模块的温湿度数据和控制其上面的LED灯
int main()
{
	int main_flag=0;//显示控制界面图片的标志
	int x,y;
	char buf[20];
	bzero(buf,20);
	
	dev_init();
	sercial_init();

	
#if 0	//不编译
	//----闪灯----通过串口发送给协调器，协调器收到命令做出对应的操作，用来测试同时作为启动标志
	MYDEBUG("start 1 led\n");
	
	write(serial2,"L01",4);	
	sleep(1);
	write(serial2,"L00",4);	
	sleep(1);
	write(serial2,"L11",4);	
	sleep(1);
	write(serial2,"L10",4);
	sleep(1);
		
	MYDEBUG("end 1 led\n");
	//-----------------------------
#endif
	while(1)
	{
		if(main_flag==0)
		{
			show_bmp("xxx.bmp",0,0,0);//功能选择界面，灯控还是监测温湿度
			main_flag=1;
		}
		get_x_y(&x,&y);
		
		//灯光控制
		if(x>286 && x<395 && y>211 && y<321)
		{			
			light_ctl();
			main_flag=0;			
		}		
		
		//环境检测
		if(x>584 && x<686 && y>206 && y<281)
		{			
			envr_ctl();	
			main_flag=0;
		}	
		//退出系统
		if(x>921 && x<1024 && y>405 && y<518)
		{			
			break;
		}
	}
	
	
	dev_close();
	
	return 0;
	
}
